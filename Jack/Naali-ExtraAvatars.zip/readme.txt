These are avatars & attachments from the legacy realXtend viewer, packaged so that 
they can easily be used with Naali's avatar editor.

The package is divided into 2 directories: Avatars & Attachments. It can be extracted 
anywhere on computer: it is not necessary to extract inside a Naali installation.

When creating new avatar files for use with Naali, all the resources needed for one
avatar or attachment (xml, mesh, skeleton, material scripts, texture files) should
reside in the same directory. For example all resources used by the Jack avatar could
be inside a Jack subdirectory. All avatars' datas don't have to reside in the same
directory like in this package, it was just a quick and dirty approach.
